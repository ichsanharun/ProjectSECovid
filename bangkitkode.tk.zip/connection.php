<?php
define("HOST", "fdb20.awardspace.net");
define("USER", "2779166_bangkit");
define("PASSWORD", "sentinel17");
define("DATABASE", "2779166_bangkit ");

$mysqli = new mysqli(HOST,USER,PASSWORD,DATABASE);

if($mysqli->connect_error){
  trigger_error('FAIL to connect to database: '.$mysqli->connect_error, E_USER_ERROR);
}
 ?>
