<div class="apps-content-item">
<table id="tbl" width="100%">
  <tr>
    <th>No.</th>
    <th>NIP</th>
    <th>Nama</th>
    <th>E-Mail</th>
    <th>JK</th>
    <th>Opsi</th>

  </tr>
  <?php
  $no = 0;
  foreach ($sql_pimpinan as $key) {
    extract($key);
  $no++;
  ?>
  <tr text-align="center">
    <td><?php echo $no; ?></td>
    <td><?php echo $id_pimpinan; ?></td>
    <td><?php echo $nama_pimpinan; ?></td>
    <td><?php echo $email_pimpinan; ?></td>
    <td><?php echo $jk_pimpinan; ?></td>
    <td align='center'>
     <a href="index.php?p=d_pimpinan_tools&id=<?php echo $id_pimpinan; ?>&aksi=detail" class="fa fa-fw fa-arrow-circle-right" title="Rincian Profile"></a>
  </tr>
<?php } ?>
</table>
<!--a href="index.php?p=d_pimpinan_tools&aksi=tambah" class="btn btn-default"><i class="fa fa-fw fa-plus" style="color:#000"></i>Tambah</a-->


</div>
