<div class="jumbotron">
  <h1 style="">Selamat Datang</h1>
  <hr></hr>
  <div style="font: 20px Georgia; color:#CC3300"><?php echo $_SESSION['nama']; echo "  ||  Hak Akses: "; echo $_SESSION['hak']; ?></div>
  <p style="font: 20px Times New Roman;">
  Selamat datang di Halaman <strong style="font-style:italic"> Admin</strong>. Fasilitas ini merupakan salah satu bentuk pelayanan dalam menyediakan dan mengelola informasi mengenai yang berkaitan dengan aktivitas dalam perusahaan dan diharapkan dapat mengelola informasi dengan mudah melalui fasilitas ini.
  </p>
</div>
