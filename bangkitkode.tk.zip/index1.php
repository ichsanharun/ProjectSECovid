<html lang="en">
<head>
  <title>
    BangkitKode.tk
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" type="text/css" href="dist/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="dist/css/me.css">
  <link rel="stylesheet" type="text/css" href="dist/scroll/src/style.css">
  <link href="dist/fa/css/fontawesome-all.min.css" rel="stylesheet">
  <script type="text/javascript" src="dist/js/jquery.min.js"></script>
  <script type="text/javascript" src="dist/js/popper.min.js"></script>
  <script type="text/javascript" src="dist/js/jquery.PageScroll2id.js"></script>
  <script type="text/javascript" src="dist/js/scroll.js"></script>
  <script type="text/javascript" src="dist/scroll/src/delighters.js"></script>
	<script type="text/javascript" src="dist/js/bootstrap.min.js"></script>
</head>
<body style="">
  <?php include 'connection.php'; ?>
  <nav data-delighter class="navbar left fixed-top navbar-expand-md navbar-light bg-info">
    <div class="container">
      <a href="index.php" class="navbar-brand">
        <img data-delighter class="bottom" src="img/logo.png" width="40" height="40" alt="">
        Bangkit Kode</a>
      <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbar1" aria-expanded="false">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse justify-content-end" id="navbar1">
        <ul class="nav navbar-nav">
          <li class="nav-item"><a class="nav-link" href="#home">Home</a></li>
          <li class="nav-item"><a class="nav-link" href="#about">About</a></li>
          <li class="nav-item"><a class="nav-link" href="#resume">My Resume</a></li>
          <li class="nav-item"><a class="nav-link" href="#contact">Contact</a></li>
          <li class="nav-item"><a class="nav-link" href="#login">Login</a></li>
        </ul>
      </div>
    </div>
  </nav>
  <div class="full-content-1" id="home">
    <div id="navbar1">
      <img data-delighter src="img/logo.png" class="right rounded-circle mx-auto d-block" width="150" height="150" alt="">

      <h1 data-delighter class="left" style="text-align:center;padding-top:30px;">Become an Enthusias Coder</h1>
        <hr size="30">
        <p data-delighter class="welcome mx-auto d-block right" style="">
          Welcome! 1 more step you will be able to determine your life by studying with BangkitKode.
          In this case BangkitKode is engaged in the field of computer and technology,
          especially in web programming assisted by our teachers.
        </p>
        <hr>
        <a data-delighter class="btn btn-custom-info right" href="#login">Login As ICT Member</a>
        <a data-delighter class="btn btn-custom-info right" data-toggle="modal" data-target="#signup">SignUp As ICT Member</a>
    </div>
  </div>


  <div class="foo" data-delighter>
  <div class="full-content-2 ended" data-delighter id="login">
    <div class="row justify-content-md-center">
    <div class="col-md-6">
      <div data-delighter class="card right start">
        <div class="card-header">
          <strong> Login As ICT 71</strong>
        </div>
        <div class="card-body">
          <div class="row">
            <div class="mx-auto my-auto d-block">
              <img class="mx-auto d-block mb-3" width="150"
                src="img/logo71.png" alt="">
            </div>
            <form role="form" action="login-selection.php" method="POST" class="my-auto d-block">
              <div class="col">
                <div class="input-group mb-3">
                  <div class="input-group-prepend">
                    <span class="input-group-text">
                      <i class="fas fa-at"></i>
                    </span>
                    <input class="form-control" placeholder="Username" name="user" type="text">
                  </div>
                </div>
              <//div style="background-image: url('https://dewey.tailorbrands.com/production/brand_version_mockup_image/132/643005132_4ed105ca-8637-41d2-bf54-a451298d717d.png?cb=1521097731');" data-testing-id="edit-brand-mockup-img" class="image-container flex-grow-1">
                      <//div>
                <div class="input-group mb-3">
                  <div class="input-group-prepend">
                    <span class="input-group-text">
                      <i class="fas fa-key"></i>
                    </span>
                    <input class="form-control" placeholder="Password" name="password" type="password" value="">
                  </div>
                </div>

                <div class="row">
                  <div class="btn-group">
                    <button type="button" class="btn btn-danger dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      More Option
                    </button>
                    <div class="dropdown-menu">
                      <a class="dropdown-item btn btn-default" data-toggle="modal" data-target="#signup"><i class="fa fa-plus"></i>Register</a>
                      <a class="dropdown-item" href="#forget"><i class="fa fa-puzzle-piece"></i>Forget Password</a>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <input type="submit" class="btn btn-md btn-primary btn-block" value="Sign in">
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
        <div class="card-footer ">
        </div>
      </div>
    </div>
    <!--div class="col-md-6">

      </div-->
    </div>
    </dev>
  </div>
  </div>


  <script type="text/javascript">
  $(document).ready(function () {
    $('#navbar1 > ul.nav li a').click(function(e) {
var $this = $(this);
$this.parent().siblings().removeClass('active').end().addClass('active');
e.preventDefault();
});
            });
  </script>
</body>
<div class="modal fade" id="signup" tabindex="-1" role="dialog" aria-labelledby="signup" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Sign Up to Join</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="login-selection.php" method="POST" class="">


            <div class="form-group">
              <label>E-Mail</label>
              <input class="form-control" placeholder="E-Mail" name="user" type="text">
            </div>

            <div class="form-group">
              <label>Your First and Last Name</label>
              <div class="input-group">
                <input type="text" placeholder="First Name" class="form-control">
                <input type="text" placeholder="Last Name" class="form-control">
              </div>
            </div>

            <div class="form-group">
              <label>Birthday</label>
              <div class="input-group">
                <input class="form-control" placeholder="Place" name="tempat_lahir" type="text">
                <input class="form-control" placeholder="Birthday" name="tanggal_lahir" type="date">
              </div>
            </div>

            <div class="form-group">
              <label>Password</label>
              <input class="form-control" placeholder="Password" name="password" type="password">
            </div>


            <div class="form-group">
              <input type="submit" class="btn btn-lg btn-primary btn-block" value="Sign in">
            </div>

        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>
</html>
