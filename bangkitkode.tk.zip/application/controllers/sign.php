<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class sign extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	 public function __construct()
	 {
			 parent::__construct();
			 $this->load->database();
			 $this->load->library('form_validation');
			 $this->load->helper('url');
			 $this->load->model('b_data');
			 $this->load->helper('captcha');
	 }
	public function index()
	{
		$data['kelas'] = $this->b_data->getAllasc('kelas','kelas')->result();
		$data['prov'] = $this->b_data->getAllasc('provinces','name')->result();
		$data['reg'] = $this->b_data->getAllasc('regencies','name')->result();
		$this->load->view('v_home', $data);
	}

	public function aksi_register()
	{
			$nisn									=$this->input->post('nisn');
			$email_member					=$this->input->post('email_member');
			$nama_member					=$this->input->post('nama_member');
			$id_kelas							=$this->input->post('id_kelas');
			$jk_member						=$this->input->post('jk_member');
			$tempat_lahir_member	=$this->input->post('tempat_lahir_member');
			$tanggal_lahir_member	=$this->input->post('tanggal_lahir_member');
			$no_hp								=$this->input->post('no_hp');
			$alamat_member				=$this->input->post('alamat_member');
			$id_provinces					=$this->input->post('id_provinces');
			$id_regencies					=$this->input->post('id_regencies');
			$foto									=$this->input->post('foto');
			$password							=$this->input->post('password');
			$conf_password				=$this->input->post('conf_password');

			if ($password == $conf_password) {

			$config['upload_path'] ='./img/pp';
	    	$config['allowed_types'] = 'jpg|png|jpeg|pdf|doc|docx|gif';
	    	$config['max_size']  = '2048';
	    	$this->load->library('upload', $config);
				$up = $this->upload->data();
			$data = array(
				"nisn"								=>$nisn,
				"email_member"				=>$email_member,
				"nama_member"					=>$nama_member,
				"id_kelas"						=>$id_kelas,
				"jk_member"						=>$jk_member,
				"tempat_lahir_member"	=>$tempat_lahir_member,
				"tanggal_lahir_member"=>$tanggal_lahir_member,
				"no_hp"								=>$no_hp,
				"alamat_member"				=>$alamat_member,
				"id_provinces"				=>$id_provinces,
				"id_regencies"				=>$id_regencies,
				"foto"								=>$up['file_name'],
				"password"						=>$password,
				"status_member"				=>"Aktif",
				"status_aktivasi"			=>"Aktif",
			);
			$this->db->insert('member',$data);
			//redirect('home');
			print_r($data);
				// $getid=$this->db->query("select * from dosen_tb where NIK='$username'")->result();
			}
			else {
				echo "Gagal";
			}


	}
}
