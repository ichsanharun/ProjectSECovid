<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	 public function __construct()
	 {
			 parent::__construct();
			 $this->load->model('B_data');
			 	if($this->session->userdata('status') != "login"){
   	 			redirect(base_url("Home"));
				}
	 }
	public function index()
	{
		$data['kelas'] = $this->B_data->getAllasc('kelas','kelas')->result();
		$data['prov'] = $this->B_data->getAllasc('provinces','name')->result();
		$data['reg'] = $this->B_data->getAllasc('regencies','name')->result();
		$this->load->view('member/v_index', $data);
	}

	public function aksi_register()
	{
			$nisn									=$this->input->post('nisn');
			$email_member					=$this->input->post('email_member');
			$nama_member					=$this->input->post('nama_member');
			$id_kelas							=$this->input->post('id_kelas');
			$jk_member						=$this->input->post('jk_member');
			$tempat_lahir_member	=$this->input->post('tempat_lahir_member');
			$tanggal_lahir_member	=$this->input->post('tanggal_lahir_member');
			$no_hp								=$this->input->post('no_hp');
			$alamat_member				=$this->input->post('alamat_member');
			$id_provinces					=$this->input->post('id_provinces');
			$id_regencies					=$this->input->post('id_regencies');
			$foto									=$this->input->post('foto');
			$pass									=$this->input->post('password');
			$conf_password				=$this->input->post('conf_password');

			if ($pass == $conf_password) {
				$m5 = hash('md5', $pass);
			$config['upload_path'] ='./img/pp';
	    	$config['allowed_types'] = 'jpg|png|jpeg|pdf|doc|docx|gif';
	    	$config['max_size']  = '1024';
	    	$this->load->library('upload', $config);
				$this->upload->do_upload('foto');
				$p5 = hash('md5', $m5);
				$up = $this->upload->data();
			$data = array(
				"nisn"								=>$nisn,
				"email_member"				=>$email_member,
				"nama_member"					=>$nama_member,
				"id_kelas"						=>$id_kelas,
				"jk_member"						=>$jk_member,
				"tempat_lahir_member"	=>$tempat_lahir_member,
				"tanggal_lahir_member"=>$tanggal_lahir_member,
				"no_hp"								=>$no_hp,
				"alamat_member"				=>$alamat_member,
				"id_provinces"				=>$id_provinces,
				"id_regencies"				=>$id_regencies,
				"foto"								=>$up['file_name'],
				"unicode"							=>$p5,
				"status_member"				=>"Aktif",
				"status_aktivasi"			=>"0",
			);


			if ($this->db->insert('member',$data)){
			//redirect('home');
		}else {
			echo "Gagal";
		}
				// $getid=$this->db->query("select * from dosen_tb where NIK='$username'")->result();
			}
			else {
				echo "Gagal";
			}


			//enkripsi id
    	$encrypted_id = hash('md5', $email_member);;

			$this->load->library('email');
	    $config = array();
	    $config['charset'] = 'utf-8';
	    $config['useragent'] = 'Codeigniter';
	    $config['protocol']= "smtp";
	    $config['mailtype']= "html";
	    $config['smtp_host']= "smtp.gmail.com";//pengaturan smtp
	    $config['smtp_port']= "465";
	    $config['smtp_timeout']= "7";
	    $config['smtp_user']= "ichsan.clay@gmail.com"; // isi dengan email kamu
	    $config['smtp_pass']= "astral17"; // isi dengan password kamu
	    $config['crlf']="\r\n";
	    $config['newline']="\r\n";
	    $config['wordwrap'] = TRUE;
	    //memanggil library email dan set konfigurasi untuk pengiriman email
			$this->email->initialize($config);
	    //konfigurasi pengiriman
	    $this->email->from($config['smtp_user']);
	    $this->email->to($email_member);
	    $this->email->subject("Verifikasi Akun");
	    $this->email->message(
	     "terimakasih telah melakuan registrasi, untuk memverifikasi silahkan klik tautan dibawah ini<br><br>".
	      site_url("Register/verification/$encrypted_id")
	    );
			if($this->email->send())
	    {
	       echo "Berhasil melakukan registrasi, silahkan cek email kamu";
	    }else
	    {
	       echo "Berhasil melakukan registrasi, namu gagal mengirim verifikasi email";
	    }

	    echo "<br><br><a href='".site_url("home")."'>Kembali ke Menu Login</a>";


	}

	public function checking(){
		$uid = $this->input->post('uid');
		$p5 = md5($this->input->post('p5'));
		$where = array(
			'email_member' => $uid,
			'unicode' => md5($p5)
		);
		$cek = $this->db->get_where('member',$where)->num_rows();
		if ($cek>0) {
			$data = $this->db->get_where('member',$where)->result();
			foreach ($data as $key) {
				$nama = $key->nama_member;
			}
			$data_session = array(
					'nama' => $nama,
				'status' => "login"
			);

			$this->session->set_userdata($data_session);
			$message = "Selamat, anda login dengan nama ".$this->session->userdata('nama').$this->session->userdata('status');
			echo "<script type='text/javascript'>
               alert ('".$message."');
               document.write ('<center><h1> Harap Masukan Username Dan Password Dengan Benar !</h1></center>');
      </script>";
		}
		else {
			echo "<script type='text/javascript'>
               alert ('Maaf Username Dan Password Anda Salah !');
               document.write ('<center><h1> Harap Masukan Username Dan Password Dengan Benar !</h1></center>');
      </script>";
		}
	}
}
