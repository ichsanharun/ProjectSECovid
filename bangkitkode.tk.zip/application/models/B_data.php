<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class B_data extends CI_Model {
		public function login($table,$where){
			return $this->db->get_where($table,$where);
		}

		public function getAll($table)
		{
      $this->load->database();
			$query=$this->db->get($table);
			return $query;
		}

    public function getAllasc($table,$order)
		{
			$query=$this->db->query("SELECT * FROM $table order by $order asc");
			return $query;
		}

		public function getWhere($table, $id)
		{
			$query=$this->db->get_where($table, $id);
			return $query->row();
		}

		public function delete($table, $id)
		{
			$query = $this->db->delete($table,$id);
			return $query;
		}

		public function insertdata($table, $data){
			return $this->db->insert($table, $data);
		}


		public function updated($table, $data, $where, $id){
			$this->db->where($where, $id);
			$this->db->update($table, $data);

		}


}

/* End of file m_data.php */
/* Location: ./application/models/m_data.php */
