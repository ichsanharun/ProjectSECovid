<html lang="en">
<head>
  <title>
    BangkitKode.tk
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" type="text/css" href="<?= base_url('dist/css/bootstrap.min.css'); ?>">
  <link rel="stylesheet" type="text/css" href="<?= base_url('dist/css/me.css'); ?>">
  <link rel="stylesheet" type="text/css" href="<?= base_url('dist/scroll/src/style.css'); ?>">
  <?= base_url('dist/scroll/src/style.css'); ?>
  <link href="<?= base_url('dist/fa/css/fontawesome-all.min.css'); ?>" rel="stylesheet">
  <script type="text/javascript" src="<?= base_url('dist/js/jquery.min.js'); ?>"></script>
  <script type="text/javascript" src="<?= base_url('dist/js/popper.min.js'); ?>"></script>
  <script type="text/javascript" src="<?= base_url('dist/js/svd.js'); ?>"></script>
  <script type="text/javascript" src="<?= base_url('dist/js/jquery.PageScroll2id.js'); ?>"></script>
  <script type="text/javascript" src="<?= base_url('dist/js/scroll.js'); ?>"></script>
  <script type="text/javascript" src="<?= base_url('dist/scroll/src/delighters.js'); ?>"></script>
	<script type="text/javascript" src="<?= base_url('dist/js/bootstrap.min.js'); ?>"></script>

</head>
<body style="">

  <nav data-delighter class="navbar left fixed-top navbar-expand-md navbar-light bg-info">
    <div class="container">
      <a href="index.php" class="navbar-brand">
        <img data-delighter class="bottom" src="<?= base_url('img/logo.png')?>" width="40" height="40" alt="">
        Bangkit Kode</a>
      <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbar1" aria-expanded="false">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse justify-content-end" id="navbar1">
        <ul class="nav navbar-nav">
          <li class="nav-item active"><a class="nav-link" href="#home">Home</a></li>
          <li class="nav-item"><a class="nav-link" href="#about">About</a></li>
          <li class="nav-item"><a class="nav-link" href="#resume">My Resume</a></li>
          <li class="nav-item"><a class="nav-link" href="#contact">Contact</a></li>
          <li class="nav-item"><a class="nav-link" href="#login">Login</a></li>
        </ul>
      </div>
    </div>
  </nav>
  <div class="foo" data-delighter>
    <div class="full-content-1" id="home">
      <div id="navbar1">
        <img data-delighter src="<?= base_url('img/logo.png" class="right start rounded-circle mx-auto d-block" width="150" height="150')?>" alt="">
        <?php if ($this->uri->segment(2)=='ied'): ?>
          <h1 data-delighter class="left" style="text-align:center;padding-top:30px;">Become an Enthusias Coder</h1>
          <hr size="30">
          <p data-delighter class="welcome mx-auto d-block right" style="font-size:33">
            We have carried out fasting for one full month during Ramadan. So on this occasion, in this glorious month, do you want to forgive everyone?
          </p>
          <hr>
          <!--a class="btn btn-custom-info" href="#login">Login As ICT Member</a-->
          <a class="btn btn-success" onclick="ucapin()" id="sign">Yes</a>
          <a class="btn btn-danger" data-toggle="modal" data-target="#malu2in" onclick="ucapin2()" id="sign">No</a>

          <!--<div class="typewriter">
          <h1>The cat and the hat.</h1>
        </div>-->
        <hr style="display:none" id="hr_ucapan">
        <div id="xucapan" class="ucapan" style="display:none; font-size:28; font-family: fixedsys, monospace;" >
          <p id="" class="mt-3"><strong>Taqobbalallaahu minna wa minkum</strong></p>
          <p id="" style="top:-30px !important"><strong>Happy Eid Al-Fitr Mubarrok 1441 H</strong></p>
        </div>

      <?php else: ?>
        <h1 data-delighter class="left" style="text-align:center;padding-top:30px;">Become an Enthusias Coder</h1>
        <hr size="30">
        <p data-delighter class="welcome mx-auto d-block right" style="">
          Welcome! 1 more step you will be able to determine your life by studying with BangkitKode.
          In this case BangkitKode is engaged in the field of computer and technology,
          especially in web programming assisted by our teachers.
        </p>
        <hr>
        <!--a class="btn btn-custom-info" href="#login">Login As ICT Member</a-->
        <a class="btn btn-custom-info" data-toggle="modal" data-target="#signup" onclick="debug()" id="sign">SignUp As ICT Member</a>
      <?php endif; ?>
    </div>
  </div>
  </div>





  <div class="foo" data-delighter>
  <div class="full-content-2 ended" data-delighter id="login">
    <div class="row justify-content-md-center">
    <div class="col-md-6">
      <div data-delighter class="card right start">
        <div class="card-header">
          <strong> Login As ICT 71</strong>
        </div>
        <div class="card-body">
          <div class="row">
            <div class="mx-auto my-auto d-block">
              <img class="mx-auto d-block mb-3" width="150"
                src="<?= base_url('img/logo71.png')?>" alt="">
            </div>
            <form role="form" action="<?php echo base_url().'Home/checking' ?>" method="POST" class="my-auto d-block">
              <div class="col">
                <div class="input-group mb-3">
                  <div class="input-group-prepend">
                    <span class="input-group-text">
                      <i class="fas fa-at"></i>
                    </span>
                    <input class="form-control" placeholder="E-Mail" name="uid" type="text">
                  </div>
                </div>
                <div class="input-group mb-3">
                  <div class="input-group-prepend">
                    <span class="input-group-text">
                      <i class="fas fa-key"></i>
                    </span>
                    <input class="form-control" placeholder="Password" name="p5" type="password" value="">
                  </div>
                </div>

                <div class="row">
                  <div class="btn-group">
                    <button type="button" class="btn btn-danger dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      More Option
                    </button>
                    <div class="dropdown-menu">
                      <a class="dropdown-item btn btn-default" data-toggle="modal" data-target="#signup"><i class="fa fa-plus"></i>Register</a>
                      <a class="dropdown-item" href="#forget"><i class="fa fa-puzzle-piece"></i>Forget Password</a>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <!--input type="submit" class="btn btn-md btn-primary btn-block" value="Sign in"-->
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
        <div class="card-footer ">
        </div>
      </div>
    </div>
    <!--div class="col-md-6">

      </div-->
    </div>
    </dev>
  </div>
  </div>


  <script type="text/javascript">
  $(document).ready(function () {
    $('#navbar1 > ul.nav li a').click(function(e) {
    var $this = $(this);
    $this.parent().siblings().removeClass('active').end().addClass('active');
    e.preventDefault();
    });
  });
  function ucapin() {
    $('.ucapan').css("display", "block");
    $('#hr_ucapan').css("display", "block");
    //$('.ucapan').addClass('line-1 anim-typewriter');
    $('#xucapan').addClass('css-typing');
  }
  function ucapin2() {
    $('#ucapin2').addClass('line-1 anim-typewriter');
  }
  </script>
</body>
<div class="modal fade" id="signup" tabindex="-1" role="dialog" aria-labelledby="signup" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Sign Up to Join</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="<?php echo base_url().'Home/aksi_register' ?>" method="post" class="" enctype="multipart/form-data">

          <div class="form-group">
            <label>NISN</label>
            <input class="form-control is-warning" placeholder="Type Your NISN if you are 71 SHS student!" id="NISN" name="nisn" type="text" required autofocus>
              <div class="note "></div>
          </div>

            <div class="form-group has-success">
              <label>E-Mail</label>
              <input class="form-control " placeholder="E-Mail" id="Email" name="email_member" type="text" required>
              <div class="note "></div>
            </div>

            <div class="form-group">
              <label>Your Name</label>
              <div class="input-group">
                <input type="text" placeholder="Name" name="nama_member" id="name" class="form-control" required>
                <div class="note "></div>
              </div>
            </div>

            <div class="form-group">
              <label>Grade:</label>
              <div class="input-group">
                <div class="input-group mb-3">
                  <select type="text" name="id_kelas" class="form-control col-md-6" id="inputGroupSelect01" required>
                    <option selected>Choose class...</option>
                    <?php foreach ($kelas as $data) { ?>
                      <option value="<?php echo $data->id_kelas; ?>"><?php echo $data->kelas; ?></option>
                    <?php } ?>
                    <option value="0">Kelas Umum</option>
                  </select>
                </div>
              </div>
            </div>

            <div class="form-group">
              <label>Sex</label>
              <div class="input-group form-control"><p>
                <input type="radio" class="" name="jk_member" value="L"> Laki-Laki
                <input type="radio" class="" name="jk_member" value="P"> Perempuan</p>
              </div>
            </div>

            <div class="form-group">
              <label>Birthday</label>
              <div class="input-group">
                <input class="form-control" placeholder="Place" name="tempat_lahir_member" type="text" required>
                <input class="form-control" placeholder="Birthday" name="tanggal_lahir_member" type="date" required>
              </div>
            </div>

            <div class="form-group">
              <label>No. Telp</label>
              <input class="form-control" placeholder="No. HP" name="no_hp" type="text" id="hp" required>
            </div>

            <div class="form-group">
              <div class="input-group">
                <div class="input-group mb-3">
                  <div class="input-group-prepend">
                    <label class="input-group-text" for="inputGroupSelect01">Street Address</label>
                  </div>
                  <input class="form-control" placeholder="Street Address" name="alamat_member" type="text" required>
                </div>
              </div>
              <div class="input-group">
                <div class="input-group mb-3">

                  <select type="text" name="id_provinces" class="form-control col-md-6" id="inputGroupSelect01" required>
                    <option selected>Choose Provincies...</option>
                    <?php foreach ($prov as $data) { ?>
                      <option value="<?php echo $data->id_provinces; ?>"><?php echo $data->name; ?></option>
                    <?php } ?>
                  </select>
                  <select type="text" name="id_regencies" class="form-control col-md-6" id="inputGroupSelect01" required>
                    <option selected>Choose Regencies...</option>
                    <?php foreach ($reg as $data) { ?>
                      <option value="<?php echo $data->id_regencies; ?>"><?php echo $data->name; ?></option>
                    <?php } ?>
                  </select>
                </div>
              </div>
            </div>

            <div class="form-group">
              <label>Upload Photo</label>
              <input class="form-control" name="foto" type="file" required>
            </div>

            <div class="form-group">
              <label>Password</label>
              <input class="form-control" placeholder="Password" name="password" id="password" type="password" required>
              <div class="note "></div>
            </div>

            <div class="form-group">
              <label>Confirm Password</label>
              <input class="form-control" placeholder="Confirm Password" name="conf_password" id="conf_password" type="password" required>
              <div class="note "></div>
            </div>


            <div class="form-group">
              <button type="submit" id="submit" class="btn btn-md btn-primary btn-block">Submit</button>
            </div>

        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="malu2in" tabindex="-1" role="dialog" aria-labelledby="signup" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Warning!</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <p data-delighter class="welcome mx-auto d-block right" style="font-size:33">
          <strong>Are you not ashamed of Allah, who forgives all beings?</strong>
        </p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" data-dismiss="modal">Repentance</button>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript" src="<?= base_url('dist/js/svd.js')?>"></script>

</html>
